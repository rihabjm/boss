package tn.techcare.PlateformeFormation.controller;

import java.sql.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import tn.techcare.PlateformeFormation.model.Formateur;
import tn.techcare.PlateformeFormation.model.Formation;
import tn.techcare.PlateformeFormation.model.FormationMetiers;
import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.service.FormationService;


@CrossOrigin("*")
@RestController
@RequestMapping("/formation")
public class FormationController {
	@Autowired
	private  FormationService formationService ;
	
	@PostMapping("/add")
	private MessageReponse ajouterreunion (@RequestBody Formation formation) {
		return formationService.ajoutFormation(formation);
	}
	
  @GetMapping("/get")
  private List<Formation> getallformation()
  {
	 return formationService.getAllFormation();
  }
  
  @GetMapping("/byintitule/{intitule}")
	private List<Formation> getbyintitule(@PathVariable("intitule")String  intitule) {
		return formationService.getformationbyintitule(intitule) ;
		
	}
  
  @GetMapping("/byprix/{prix}")
	private List<Formation> getbyprix(@PathVariable("prix")float prix ) {
		return formationService.getformationbyPrix(prix);
	}
  

  
  @GetMapping("/bytype/{type}")
 	private List<Formation> getbytype(@PathVariable("type")String type ) {
 		return formationService.getformationbytype(type) ;}
  
   
  
	@GetMapping("/byid/{id}")
	private  Formation getbyId(@PathVariable("id")Long  id) {
		return formationService.getformationbyId(id) ;
	
	}

	@DeleteMapping("{id}")
	private MessageReponse deletformation (@PathVariable("id") Long id) {
		return formationService.supprimerFormation(id) ;
		
	}
	
	/* @GetMapping("/getnotaffect")
		private boolean getformationnotafected(@RequestParam String intitule ,@RequestParam Date datedebut,@RequestParam Date datefin  ) {
			return formationService.getformationnonaffecte(intitule,datedebut, datefin);
			
		}
	
	*/
	
}
