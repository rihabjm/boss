package tn.techcare.PlateformeFormation.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import tn.techcare.PlateformeFormation.model.Promotion;
@Repository
public interface PromotionRepository extends JpaRepository<Promotion,Long> {
	Promotion findPromotionByIdpromotion(Long idpromotion ) ;

}
