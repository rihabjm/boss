package tn.techcare.PlateformeFormation.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.model.Planing;
import tn.techcare.PlateformeFormation.model.Remise;
import tn.techcare.PlateformeFormation.service.PlaningService;

@CrossOrigin("*")
@RestController
@RequestMapping("/planing")
public class PlaningController {

	@Autowired 
	private PlaningService planingservice ;
	
	@PostMapping("/add/{idCategory}/{id}")
	public MessageReponse ajouterpalning (@RequestBody Planing  planing ,@PathVariable("idCategory")long  idsession ,@PathVariable("id") int idseance,@PathVariable("idsalle")long  idsalle){
	    
		return planingservice.Ajouterplaning(planing, idsession, idseance, idsalle) ;
	}
	  
	
	
}
