package tn.techcare.PlateformeFormation.service;

import tn.techcare.PlateformeFormation.model.CV;
import tn.techcare.PlateformeFormation.model.Certificat;

public interface CVService {
	public CV uploadimageFormateur(CV cv , long idformateur)  ;

}
