package tn.techcare.PlateformeFormation.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import tn.techcare.PlateformeFormation.model.Image;


public interface ImgRepository extends JpaRepository<Image, Long>  {
    Optional<Image> findByName(String name);

}
