package tn.techcare.PlateformeFormation.controller;
import java.sql.Date;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.annotation.JsonIgnore;

import tn.techcare.PlateformeFormation.model.Formateur;
import tn.techcare.PlateformeFormation.model.ImageModel;
import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.model.Utilisateur;
import tn.techcare.PlateformeFormation.model.specialiite;
import tn.techcare.PlateformeFormation.service.FormateurService;

import java.io.ByteArrayOutputStream;

import java.io.IOException;
import java.util.zip.Deflater;




 @CrossOrigin("*")
@RestController
@RequestMapping("/formateur")
public class FormateurController {

	@Autowired
	private  FormateurService formateurService ;
	/* 
	@Autowired
	private  NotificationService notificationservice ;*/
	
	
	/*@RequestParam("imageFile") MultipartFile fileimage*/
	@PostMapping("/add")
	@JsonIgnore
	private Formateur AjoutFormateur (@RequestBody Formateur formateur  ) throws IOException {
	   Utilisateur user =new Utilisateur();
	   user.setGmail("rihabjemai35@gmail.com");


	return formateurService.AjoutFormateur(formateur);
	}
	
	@PutMapping("/affectspecialite/{idCategory}")
	@JsonIgnore
	private Formateur affectspecialite (@RequestBody long idsp ,@PathVariable("idCategory") Long idformateur   ) throws IOException {
	return formateurService.affectspecilite(idsp, idformateur) ;
	}
	
	  
  @GetMapping("/get")
  private List<Formateur> getallFormateur()
  {
	  return formateurService.getAllFormateur();
  }
  

@PutMapping("/update")
private MessageReponse ModifierFormateur (@RequestBody Formateur formateur ) {
	return formateurService.ModifierFormateur(formateur) ;
	
}


@DeleteMapping("{id}")
private MessageReponse SupprimerFormateur (@PathVariable("id") Long id) {
	return formateurService.SupprimerFormateur(id) ;
	
}


@GetMapping("/bynom/{nom}")
private List<Formateur> getbynom(@PathVariable("nom")String  nom) {
	return formateurService.getFormateurByNom(nom) ;
	
}
@GetMapping("/byprenom/{prenom}")
private List<Formateur> getbyprenom(@PathVariable("prenom")String  prenom) {
	return formateurService.getFormateurByPrenom(prenom);
	
}
@GetMapping("/byadresse/{adresse}")
private List<Formateur> getbyadresse(@PathVariable("adresse")String  adresse) {
	return formateurService.getFormateurByAdresse(adresse);
}

@GetMapping("/bytel/{telephone}")
private List<Formateur> getbytel(@PathVariable("telephone")int  telephone) {
	return formateurService.getFormateurByTelephone(telephone);
}




@GetMapping("/bydatenaiss/{dateNAisse}")
private List<Formateur> getbym(@PathVariable("dateNAisse")Date  dateNAisse) {
	return formateurService.getFormateurByDateNAisse(dateNAisse);

}

@GetMapping("/byid/{id}")
private Formateur getbyid(@PathVariable("id")Long  id) {
	return formateurService.getFormateurById(id) ;

}

@GetMapping("/getspecialite/{id}")
private List<specialiite> getspecialite(@PathVariable("id")Long  id) {
	return formateurService.getSpecialite(id) ;

}   

@GetMapping("/byspecialite/{specialite}")
private List<Formateur> getbynomspecialite(@PathVariable("specialite")String  specialite) {
	return formateurService.getFormateurbyspecialite(specialite);

}
   
public static byte[] compressBytes(byte[] data) {
	 
    Deflater deflater = new Deflater();

    deflater.setInput(data);

    deflater.finish();

    ByteArrayOutputStream outputStream = new ByteArrayOutputStream(data.length);

    byte[] buffer = new byte[1024];

    while (!deflater.finished()) {

        int count = deflater.deflate(buffer);

        outputStream.write(buffer, 0, count);

    }

    try {

        outputStream.close();

    } catch (IOException e) {

    }

    System.out.println("Compressed Image Byte Size - " + outputStream.toByteArray().length);

    return outputStream.toByteArray();

}

}