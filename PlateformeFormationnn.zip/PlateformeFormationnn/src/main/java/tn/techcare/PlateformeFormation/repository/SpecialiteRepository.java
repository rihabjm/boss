package tn.techcare.PlateformeFormation.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import tn.techcare.PlateformeFormation.model.Formateur;
import tn.techcare.PlateformeFormation.model.Role;
import tn.techcare.PlateformeFormation.model.specialiite;
@Repository
public interface SpecialiteRepository  extends JpaRepository<specialiite,Long>{
	specialiite findByNomspecialite (String name);
	specialiite findByIdspecialite(Long id ) ;


}
