package tn.techcare.PlateformeFormation.Impservice;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.model.specialiite;
import tn.techcare.PlateformeFormation.repository.SessionRepository;
import tn.techcare.PlateformeFormation.repository.SpecialiteRepository;
import tn.techcare.PlateformeFormation.service.SpecialiteService;
@Service
@Transactional
public class SpecialiteImpservice implements SpecialiteService  {

	@Autowired
	private SpecialiteRepository  specialiterepoistory;
	
	
	@Override
	public MessageReponse AjouterSpecialite(specialiite specialite) {
		// TODO Auto-generated method stub
		specialiterepoistory.save(specialite) ;
		   return new MessageReponse(true, specialite.getIdspecialite()+ "specialit�  est ajouter ") ;	}


	@Override
	public List<specialiite> getAllSpecilite() {
		// TODO Auto-generated method stub
		return specialiterepoistory.findAll();
	}


	@Override
	public specialiite getspecialiteById(long id) {
		// TODO Auto-generated method stub
		return specialiterepoistory.findByIdspecialite(id)	;
		}


	@Override
	public List<specialiite> getSpeciliteByformateur(long id) {
	
		 return null ;
		
		}

	

}
