package tn.techcare.PlateformeFormation.service;

import java.sql.Date;
import java.sql.Time;
import java.util.List;
import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.model.Salle;
import tn.techcare.PlateformeFormation.model.Seance;


public interface SeanceService {
	
   public MessageReponse SupprimerSession(Long idsenace);
	  public List<Seance> getAllSeance();
	  public MessageReponse ModifierSeance(Seance senace) ;
	  public List<Seance> getAllSeancebysession(long idsession);
	  
}
