package tn.techcare.PlateformeFormation.service;

import java.util.List;

import tn.techcare.PlateformeFormation.model.Formation;
import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.model.Remise;
import tn.techcare.PlateformeFormation.model.Session;

public interface RemiseService {
    public MessageReponse Ajouterremise (Remise remise ,Long  idpromotion ,Long idsession ) ;
    
    public List<Session>getformationreise(Long idpromotion) ;
  

}
