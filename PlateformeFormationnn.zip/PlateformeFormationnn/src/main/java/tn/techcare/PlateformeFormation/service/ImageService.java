package tn.techcare.PlateformeFormation.service;

import tn.techcare.PlateformeFormation.model.ImageModel;

public interface ImageService {

	public ImageModel uploadimage(ImageModel image , long idformateur)  ;
	
}
