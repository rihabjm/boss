package tn.techcare.PlateformeFormation.model;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "image")
public class Image  extends ImageModel  {

	@OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "idformation")
    private Formation  formation;

	public Formation getFormation() {
		return formation;
	}

	public void setFormation(Formation formation) {
		this.formation = formation;
	}
	

	@OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "idformateur")
    private Formateur formateur;

	public Formateur getFormateur() {
		return formateur;
	}

	public void setFormateur(Formateur formateur) {
		this.formateur = formateur;
	}

	public Image(Formation formation, Formateur formateur) {
		super();
		this.formation = formation;
		this.formateur = formateur;
	}

	public Image() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Image(String name, String type, byte[] picByte) {
		super(name, type, picByte);
		// TODO Auto-generated constructor stub
	}
	
	
	
}
