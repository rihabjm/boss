package tn.techcare.PlateformeFormation.model;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "certificat")
public class Certificat  extends  FileModel {
	 @JsonIgnore 
	@ManyToOne(fetch = FetchType.EAGER, optional = false)
	    @OnDelete(action = OnDeleteAction.CASCADE)
	    @JoinColumn(name = "id_formateur", nullable = false)
	    private Formateur formateur;

	  
	  @ManyToOne(fetch = FetchType.EAGER, optional = false)
	    @OnDelete(action = OnDeleteAction.CASCADE)
	    @JoinColumn(name = "idspecialite", nullable = false)
	    private specialiite specialite;
	  
	  

	public Certificat() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	


	public Formateur getFormateur() {
		return formateur;
	}

	public void setFormateur(Formateur formateur) {
		this.formateur = formateur;
	}



	public specialiite getSpecialite() {
		return specialite;
	}



	public void setSpecialite(specialiite specialite) {
		this.specialite = specialite;
	}




	public Certificat(Formateur formateur, specialiite specialite) {
		super();
		this.formateur = formateur;
		this.specialite = specialite;
	}




	public Certificat(String name, String mimetype, byte[] pic) {
		super(name, mimetype, pic);
		// TODO Auto-generated constructor stub
	}
	
	
	
	  
	  
}
