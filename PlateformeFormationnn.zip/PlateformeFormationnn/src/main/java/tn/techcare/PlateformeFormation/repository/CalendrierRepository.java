package tn.techcare.PlateformeFormation.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import tn.techcare.PlateformeFormation.model.Calendrier;
import tn.techcare.PlateformeFormation.model.Formateur;

@Repository
public interface CalendrierRepository extends JpaRepository<Calendrier,Integer> {
 
	Calendrier findCalendrierById(int id ) ;

}
