package tn.techcare.PlateformeFormation.Impservice;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.model.Planing;
import tn.techcare.PlateformeFormation.model.Salle;
import tn.techcare.PlateformeFormation.model.Seance;
import tn.techcare.PlateformeFormation.model.Session;
import tn.techcare.PlateformeFormation.repository.PlaningRepository;
import tn.techcare.PlateformeFormation.repository.SalleRepository;
import tn.techcare.PlateformeFormation.repository.SeanceRepository;
import tn.techcare.PlateformeFormation.repository.SessionRepository;
import tn.techcare.PlateformeFormation.service.PlaningService;
@Service   
public class PlaningImpService implements  PlaningService {

	@Autowired 
	private PlaningRepository planingrepository ;
	@Autowired 
	private SeanceRepository senacerepository ;
	@Autowired 
	private SalleRepository sallerepository ;
	@Autowired 
	private SessionRepository sessionrepository ;
	 
	@Override
	public MessageReponse Ajouterplaning(Planing planing, Long idsession, int idseance, Long idsalle) {
		// TODO Auto-generated method stub
		Optional<Salle> salle =sallerepository.findById(idsalle);
		Optional<Seance> seance =senacerepository.findById(idseance) ;
		Optional<Session> session =sessionrepository.findById(idsession) ;
		planing.setSalle(salle.get());
		planing.setSenace(seance.get());
		planing.setSession(session.get());
		planingrepository.save(planing) ;
		
		   
		return new MessageReponse(true, "planing est ajouter ") ;
	}

}
