package tn.techcare.PlateformeFormation.controller;

import java.io.ByteArrayOutputStream;

import java.io.IOException;
import java.sql.Date;
import java.util.List;
import java.util.Optional;
import java.util.zip.Deflater;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.annotation.JsonIgnore;

import tn.techcare.PlateformeFormation.model.FormationMetiers;
import tn.techcare.PlateformeFormation.model.ImageModel;
import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.service.FormationMetiersService;


@CrossOrigin("*")
@RestController
@RequestMapping("/formationMetiers")
public class FormationMetiersController {
@Autowired
	private  FormationMetiersService formationMetiersService ;
	
	@PostMapping("/add")
	@JsonIgnore
	public  FormationMetiers ajouterreunion (@RequestBody  FormationMetiers formation ){
	      return formationMetiersService.ajoutFormation(formation);
  }
	
	
	
	
	
	@GetMapping("/get")
	public List<FormationMetiers> getAllFormationMetiers()
	{    
		return formationMetiersService.getAllFormation();
	}
	
	

	
	@PutMapping("/update")
	private MessageReponse updateformation (@RequestBody FormationMetiers  formation ) {
		return formationMetiersService.updateFormation(formation) ;
		
	}

	@DeleteMapping("{id}")
	private MessageReponse deletformation (@PathVariable("id") Long id) {
		return formationMetiersService.supprimerFormation(id) ;
		
	}


	@GetMapping("/bytype/{type}")
	private List<FormationMetiers> getbytype(@PathVariable("type")String  type) {
		return formationMetiersService.getformationbytype(type);
		
	}
	

	@GetMapping("/byintitule/{intitule}")
	private List<FormationMetiers> getbyintitule(@PathVariable("intitule")String  intitule) {
		return formationMetiersService.getformationbyintitule(intitule);
		
	}



	@GetMapping("/byprix/{prix}")
	private List<FormationMetiers> getbyprix(@PathVariable("prix")float  prix) {
		return formationMetiersService.getformationbyPrix(prix);
		
	}
	
	@GetMapping("/byid/{id}")
	private  FormationMetiers getbyId(@PathVariable("id")Long  id) {
		return formationMetiersService.getformationbyId(id) ;
	
	}
  
	
	public static byte[] compressBytes(byte[] data) {
		 
	    Deflater deflater = new Deflater();

	    deflater.setInput(data);

	    deflater.finish();

	    ByteArrayOutputStream outputStream = new ByteArrayOutputStream(data.length);

	    byte[] buffer = new byte[1024];

	    while (!deflater.finished()) {

	        int count = deflater.deflate(buffer);

	        outputStream.write(buffer, 0, count);

	    }

	    try {

	        outputStream.close();

	    } catch (IOException e) {

	    }

	    System.out.println("Compressed Image Byte Size - " + outputStream.toByteArray().length);

	    return outputStream.toByteArray();

	}
	
}
