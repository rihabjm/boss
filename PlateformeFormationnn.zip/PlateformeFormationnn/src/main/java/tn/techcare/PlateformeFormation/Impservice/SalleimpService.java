package tn.techcare.PlateformeFormation.Impservice;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.model.Salle;
import tn.techcare.PlateformeFormation.model.Seance;
import tn.techcare.PlateformeFormation.repository.SalleRepository;
import tn.techcare.PlateformeFormation.repository.SeanceRepository;
import tn.techcare.PlateformeFormation.service.SalleService;

@Service
@Transactional
public class SalleimpService implements SalleService {
	
	@Autowired
	private SalleRepository  sallerepoistory;

	@Autowired
	private SeanceRepository  seancerepoistory;

	@Override
	public List<Salle> getAllSalle() {
		// TODO Auto-generated method stub
		return sallerepoistory.findAll();
	}

	@Override
	public MessageReponse ModifierSalle(Salle salle) {
		// TODO Auto-generated method stub
		Optional<Salle>	 salle1 = sallerepoistory.findById(salle.getIdsalle()) ;
		if(salle1== null) {
			return new MessageReponse(false, "erreur , salle  introuvable");
			}
			sallerepoistory.save(salle);
			return new MessageReponse(true, "operation modifier effectue avec succes");
	}
	

	@Override
	public MessageReponse SupprimerSalle(Long idsalle) {
		// TODO Auto-generated method stub
		Optional<Salle>	 salle1 = sallerepoistory.findById(idsalle) ;
		if(salle1== null) {
		return new MessageReponse(false, "erreur , salle  introuvable");
		}
		sallerepoistory.delete(salle1.get());
		return new MessageReponse(true, "operation delet  effectue avec succes");
	}

	@Override
	public MessageReponse AjouterSalle(Salle salle) {
		// TODO Auto-generated method stub
	  sallerepoistory.save(salle);
	 return new MessageReponse(true, salle.getIdsalle()+ "salle est ajouter ") ;
	}

}
