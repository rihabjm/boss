package tn.techcare.PlateformeFormation.Impservice;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.transaction.Transactional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;


import tn.techcare.PlateformeFormation.model.Formation;
import tn.techcare.PlateformeFormation.model.FormationMetiers;
import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.model.Remise;
import tn.techcare.PlateformeFormation.repository.FormationRepository;
import tn.techcare.PlateformeFormation.service.FormationService;
@Service
@Transactional
public class FormationImpService implements FormationService {
   
	@Autowired
  private  FormationRepository fromationRepository ;
	 
	@Override
	public MessageReponse ajoutFormation(Formation formation) {
		fromationRepository.save(formation);
		return  new MessageReponse(true, formation.getIdformation()+ "formation est ajouter ") ;
	}
	@Transactional
	@Override
	public List<Formation> getAllFormation() {
		// TODO Auto-generated method stub
		return (List<Formation>) fromationRepository.findAll();

	}

	@Override
	public List<Formation> getformationbyintitule(String intitule) {
		// TODO Auto-generated method stub
		return  fromationRepository.findFormationByIntitule(intitule);
	}

	@Override
	public MessageReponse updateformation(Formation formation) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Formation getformationbyId(Long id) {
		// TODO Auto-generated method stub
		return fromationRepository.findFormationByIdformation(id);
	}
	@Transactional
	@Override
	public MessageReponse supprimerFormation(Long id) {
		// TODO Auto-generated method stub
		Formation metiers = fromationRepository.findById(id).orElse(null) ;
		if(metiers== null) {
		return new MessageReponse(false, "erreur , formation  introuvable");
		}
		fromationRepository.delete(metiers);
		return new MessageReponse(true, "operation delet effectue avec succes");	}
	@Override
	public List<Formation> getformationbytype(String type) {
		// TODO Auto-generated method stub
		
	     List<Formation> list =new ArrayList(); 
	     list =fromationRepository.findFormationByType(type);
		
		if (list ==null ) {
			System.out.println("");

		}
		return list ;
	}

	@Override
	public List<Formation> getformationbyPrix(float prix) {
		  List<Formation> list =new ArrayList(); 
		     list =fromationRepository.findFormationByPrix(prix) ;
			
			if (list ==null ) {
				System.out.println("");

			}
			return list ;
		
	}
	
	/*
	@Override	public boolean getformationnonaffecte(String intitule  , Date startDate,Date endDate) {
		Formation formations= fromationRepository.findFormationByIntitulee(intitule) ;
		List<Formation> formationsnonaffecter=new ArrayList<Formation>();
		
	
		
			List<Remise> remises=formations.getRemises() ;
			for(int j=0;j<remises.size();j++)
			{
				if((remises.get(j).getDatedebut().after(startDate)||remises.get(j).getDatefin().after(startDate))&&
						
						(remises.get(j).getDatedebut().after(endDate)||remises.get(j).getDatefin().after(endDate))	
						
						
						)
				{
				
					return true   ;
					
				}
				
			}
			
			
		
		return false ;
		
	}
*/
	
}
