package tn.techcare.PlateformeFormation.Impservice;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tn.techcare.PlateformeFormation.model.Formation;
import tn.techcare.PlateformeFormation.model.Session;
import tn.techcare.PlateformeFormation.repository.InscrirRepository;
import tn.techcare.PlateformeFormation.repository.SessionRepository;
import tn.techcare.PlateformeFormation.service.InscrirService;
import tn.techcare.PlateformeFormation.model.Inscrir;

@Service
@Transactional
public class InscrirImpService implements InscrirService {
  
	 @Autowired
	  SessionRepository sessionrepository  ;
	 @Autowired
	 InscrirRepository inscrirrepository  ;	
	 @Autowired
	 InscrirService inscrirservice  ;	
	
	@Override
	public Inscrir AjouterInscrir(Inscrir inscri) {
	
		return  inscrirrepository.save(inscri) ;
	}
	
	
    @Transactional
	@Override
	public List<Inscrir> getInscrirbySession(long idCategory) {
		List<Inscrir> listeinscrirs = new ArrayList<Inscrir>();

		List<Session>	inscrirs =sessionrepository.findAll() ;
		
		for(int index =0 ; index <inscrirs.size() ;index ++)
		{
		   
			   if(inscrirs.get(index).getIdsession()==idCategory)
			   {
				  /* listeinscrirs.addAll(inscrirs.get(index).getInscrirs()) ;*/
			   }
			   
			   
		   }
			
		
		return  listeinscrirs ;
	}
	@Override
	public List<Inscrir> getallInscri() {
		// TODO Auto-generated method stub
		return inscrirrepository.findAll(); 
	}

}
