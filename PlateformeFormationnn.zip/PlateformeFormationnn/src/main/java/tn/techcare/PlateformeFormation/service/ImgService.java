package tn.techcare.PlateformeFormation.service;

import java.util.Optional;

import tn.techcare.PlateformeFormation.model.Image;
import tn.techcare.PlateformeFormation.model.ImageModel;

public interface ImgService {
	public Image uploadimageFormateur(Image image , long idformateur)  ;
	public Image uploadimageFormation(Image image , long idformation)  ;
    public ImageModel  getImageFormateur(long idformateur);
    public Image getImageFormation(long  idformation) ;
   
}
