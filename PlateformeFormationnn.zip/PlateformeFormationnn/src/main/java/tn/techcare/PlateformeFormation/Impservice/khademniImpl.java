package tn.techcare.PlateformeFormation.Impservice;

import java.util.List;

import javax.transaction.Transactional;

import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.model.khademni;
import tn.techcare.PlateformeFormation.repository.khademniRepository ;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tn.techcare.PlateformeFormation.service.KhademniService;

@Service
@Transactional
public class khademniImpl implements KhademniService{
	 
		@Autowired
		  private  khademniRepository khademniRepository ;
			
	@Override
	public MessageReponse Ajouterkhademni(khademni khademni) {
		// TODO Auto-generated method stub
		khademniRepository.save(khademni);
		return  new MessageReponse(true, khademni.getId_khademni()+ "khademni ajoutée ") ;
	}
	@Override
	public List<khademni> getAllkhademni() {
		// TODO Auto-generated method stub
		return (List<khademni>) khademniRepository.findAll();

	}

	@Override
	public MessageReponse Modifierkhademni(khademni khademni) {
		// TODO Auto-generated method stub
		khademni khademni2 = khademniRepository .findById(khademni.getId_khademni()).orElse(null);
		System.out.println(khademni2.getId_khademni());	

		if (khademni2!=null) 
		{
			khademniRepository.save(khademni);
	           return new MessageReponse(true, "khademni modifiée");
		}
		       return new MessageReponse(false , "khademni introuvable");
	    }

	@Override
	public MessageReponse Supprimerkhademni(int id) {
		// TODO Auto-generated method stub
		khademni khademni2 = khademniRepository.findById(id).orElse(null) ;
	       if(khademni2== null) 
	       {
	       return new MessageReponse(false, "erreur , khademni introuvable");
	       }
	       khademniRepository.delete(khademni2);
	         return new MessageReponse(true, "operation delete effectue avec succes");

	       }
		
	}
 