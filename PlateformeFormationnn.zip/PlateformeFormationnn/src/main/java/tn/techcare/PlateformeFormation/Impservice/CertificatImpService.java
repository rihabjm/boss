package tn.techcare.PlateformeFormation.Impservice;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tn.techcare.PlateformeFormation.model.Certificat;
import tn.techcare.PlateformeFormation.model.Formateur;
import tn.techcare.PlateformeFormation.model.specialiite;
import tn.techcare.PlateformeFormation.repository.CVRepository;
import tn.techcare.PlateformeFormation.repository.CertificatRepository;
import tn.techcare.PlateformeFormation.repository.FormateurRepository;
import tn.techcare.PlateformeFormation.repository.SpecialiteRepository;
import tn.techcare.PlateformeFormation.service.CertificatService;
@Service
public class CertificatImpService implements CertificatService {

	@Autowired
	private FormateurRepository  formateurrepoistory;
	
	@Autowired
	private CertificatRepository  certificatrepository ;
	
	@Autowired
	private SpecialiteRepository  specialiterepository ;
	
	
	@Override
	public Certificat uploadimageFormateur(Certificat certifciat, long idformateur) {
		// TODO Auto-generated method stub
		 Formateur formateur = formateurrepoistory.findFormateurById(idformateur);
		 certifciat.setFormateur(formateur);	  
	        return certificatrepository.save(certifciat);
	}


	@Override
	public Certificat uploadCertificatspecialite(Certificat certifciat, long idspecialite) {
		// TODO Auto-generated method stub
		
		Optional<specialiite> sp =specialiterepository.findById(idspecialite);
		certifciat.setSpecialite(sp.get());
		return certificatrepository.save(certifciat);
	}

}
