package tn.techcare.PlateformeFormation.service;

import java.sql.Date;
import java.util.List;
import java.util.Optional;

import tn.techcare.PlateformeFormation.entites.MessageResponse;
import tn.techcare.PlateformeFormation.model.Formateur;
import tn.techcare.PlateformeFormation.model.ImageModel;
import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.model.specialiite;

 

public interface FormateurService {
	  public Formateur AjoutFormateur (Formateur formateur) ;
	  public List<Formateur> getAllFormateur();
      public MessageReponse ModifierFormateur(Formateur formateur) ;
	  public MessageReponse SupprimerFormateur(Long id);
	  public  Formateur    getFormateurById(Long id);
	  public Formateur affectspecilite(long idsp ,Long idformateur);

	 public	List<Formateur> getFormateurByNom(String nom ) ;
	 public	List<Formateur> getFormateurByPrenom(String prenom ) ;
     public		List<Formateur>  getFormateurByAdresse(String adresse ) ;
    public		List<Formateur> getFormateurByMail(String mail ) ;
     public		List<Formateur> getFormateurByTelephone(int telephone ) ;
		public List<Formateur> getFormateurByDateNAisse(Date datenais ) ;
		public MessageResponse save(Formateur formateur);
		
		public List<specialiite> getSpecialite(long id );   
		public List<Formateur> getFormateurbyspecialite(String specialite) ;
}
