package tn.techcare.PlateformeFormation.service;


import java.util.List;


import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.model.Salle;
import tn.techcare.PlateformeFormation.model.Seance;


public interface SalleService {


	 public MessageReponse AjouterSalle (Salle salle) ;
	  public List<Salle> getAllSalle();
	  public MessageReponse ModifierSalle(Salle salle) ;
	  public MessageReponse SupprimerSalle(Long idsalle);
	
}
