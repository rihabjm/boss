package tn.techcare.PlateformeFormation.service;

import java.sql.Date;
import java.util.List;

import tn.techcare.PlateformeFormation.model.Formation;
import tn.techcare.PlateformeFormation.model.FormationModule;
import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.model.Programmekhademni;

public interface ProgrammekhademniService {
	   public MessageReponse ajoutFormation (Programmekhademni formation) ;
	   public List<Programmekhademni> getAllFormation();
	   public List<Programmekhademni> getformationbyintitule(String intitule ) ;
	   public MessageReponse updateformation(Programmekhademni formation );
	   public Programmekhademni getformationbyId(Long id);
	   public MessageReponse supprimerFormation(Long id);
	   public List<Programmekhademni> getformationbytype(String type ) ;
	
		public List<Programmekhademni> getformationbyPrix(float prix ) ;
}
