package tn.techcare.PlateformeFormation.repository;

import java.sql.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;


import tn.techcare.PlateformeFormation.model.Formateur;

public interface FormateurRepository extends JpaRepository<Formateur,Long> {
	List<Formateur> findFormateurByNom(String nom ) ;
	List<Formateur> findFormateurByPrenom(String prenom ) ;
	List<Formateur> findFormateurByAdresse(String adresse ) ;
	List<Formateur> findFormateurByGmail(String mail ) ;
	List<Formateur> findFormateurByTelephone(int telephone ) ;
	List<Formateur> findFormateurByDateNAisse(Date datenais ) ;
	Formateur findFormateurById(Long id ) ;


	List<Formateur> findByLogin(String email);
	List<Formateur> findByLoginAndId(String email,Long id);
}
