package tn.techcare.PlateformeFormation.controller;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
 
import com.fasterxml.jackson.annotation.JsonView;

import tn.techcare.PlateformeFormation.model.CV;
import tn.techcare.PlateformeFormation.model.Certificat;
import tn.techcare.PlateformeFormation.model.FileModel;
import tn.techcare.PlateformeFormation.model.View;
import tn.techcare.PlateformeFormation.repository.CVRepository;
import tn.techcare.PlateformeFormation.repository.CertificatRepository;
import tn.techcare.PlateformeFormation.repository.FileRepository;

 
@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class DownloadFileController {

	
	@Autowired
	  FileRepository fileRepository;
	 
	@Autowired
	  CertificatRepository  certificatRepository;
	
	
	@Autowired
	 CVRepository  CvRepository;
	
	
	  /*
	   * List All Files
	   */
	    @JsonView(View.FileInfo.class)
	  @GetMapping("/api/file/all")
	  public List<FileModel> getListFiles() {
	    return fileRepository.findAll();
	  }
	    
	    
	    @JsonView(View.FileInfo.class)
		  @GetMapping("/api/file/allcv/{id}")
		  public List<CV> getListFilesCv(@PathVariable("id")Long  id) {
	    	 List<CV> cv =new ArrayList<CV>() ;
	    	 List<CV> cvs = CvRepository.findAll();
	    	 for(int i=0;i<cvs.size();i++)
	    	 {
	    		 if( cvs.get(i).getFormateur().getId()==id)
	    			 
	    		 {
	    			 
	    			 cv.add(cvs.get(i)) ;
	    		 }
	    	 }
		    return cv ;
		  }
	    
	    
	    
	    @JsonView(View.FileInfo.class)
		  @GetMapping("/api/file/allcertificat/{id}/{idsp}")
		  public List<Certificat> getListFilesCertificat(@PathVariable("id")Long  id,@PathVariable("idsp")Long  idsp) {
	    	 List<Certificat> cv =new ArrayList<Certificat>() ;
	    	 List<Certificat> cvs = certificatRepository.findAll();
	    	 for(int i=0;i<cvs.size();i++)
	    	 {
	    		 if( (cvs.get(i).getFormateur().getId()==id)&&(cvs.get(i).getSpecialite().getIdspecialite()==idsp))
	    			 
	    		 {
	    			 
	    			 cv.add(cvs.get(i)) ;
	    		 }
	    	 }
		    return cv ;
		  }
	    
	    
	    
	  
	    /*
	     * Download Files
	     */
	  @GetMapping("/api/file/{id}")
	  public ResponseEntity<byte[]> getFile(@PathVariable Long id) {
	    Optional<FileModel> fileOptional = fileRepository.findById(id) ;
	    
	    if(fileOptional.isPresent()) {
	      FileModel file = fileOptional.get();
	      return ResponseEntity.ok()
	          .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + file.getName() + "\"")
	          .body(file.getPic());  
	    }
	    
	    return ResponseEntity.status(404).body(null);
	  }
	
}
