package tn.techcare.PlateformeFormation.service;

import java.util.List;
import tn.techcare.PlateformeFormation.model.Inscrir;
import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.model.Session;

public interface SessionService {
	   public Session AjouterSession(Session session, Long idformation);
	   public MessageReponse  AjouterParticipantSession(Inscrir inscrir, Long idsession);
	   public MessageReponse SupprimerParticipant(long idinscrir ,Long idsession) ;
       public MessageReponse AjouterSession (Session session) ;
	   public List<Session> getAllSession();  
	   public List<Session> getAllSessionplanifeir();
	   public MessageReponse ModifierSession(Session session) ;
	   public MessageReponse SupprimerSession(Long id_session);
	public Session getSessionbyId(Long id);
	public List<Session> getsessionbyformation(long idCategory);
   public List<Inscrir>getinscrirbysession(long idsession) ;	
}
