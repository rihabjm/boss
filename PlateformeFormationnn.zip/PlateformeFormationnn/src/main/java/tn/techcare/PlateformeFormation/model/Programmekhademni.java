package tn.techcare.PlateformeFormation.model;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "programmekhademni")
public class Programmekhademni extends Formation {

}
