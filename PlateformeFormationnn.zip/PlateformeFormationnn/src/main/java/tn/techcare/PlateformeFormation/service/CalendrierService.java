package tn.techcare.PlateformeFormation.service;
import java.util.List;

import tn.techcare.PlateformeFormation.model.Calendrier;

public interface CalendrierService {

	public  List<Calendrier> getCalendrier() ;

	public List<Calendrier> getCalendrierbyFormation(Long id);
	public Calendrier addevent(String event ,int id ); 
	
}
