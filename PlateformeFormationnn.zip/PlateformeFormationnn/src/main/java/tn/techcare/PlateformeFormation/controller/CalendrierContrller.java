package tn.techcare.PlateformeFormation.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import tn.techcare.PlateformeFormation.model.Calendrier;
import tn.techcare.PlateformeFormation.model.Formateur;
import tn.techcare.PlateformeFormation.model.Formation;
import tn.techcare.PlateformeFormation.model.FormationMetiers;
import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.service.CalendrierService;
import tn.techcare.PlateformeFormation.service.FormationService;

@CrossOrigin("*")
@RestController
@RequestMapping("/calendrier")
public class CalendrierContrller {
	
	 @Autowired CalendrierService calendrierservice ;
	 @GetMapping("/get")
	  private List<Calendrier> getallFormateur()
	  {
		  return calendrierservice.getCalendrier() ;
	  }
	
	 @PostMapping("/products/{id}")
	    public Calendrier addProduct(String event,@PathVariable("id") int id){
	        return calendrierservice.addevent(event, id);
	    }
	

}
