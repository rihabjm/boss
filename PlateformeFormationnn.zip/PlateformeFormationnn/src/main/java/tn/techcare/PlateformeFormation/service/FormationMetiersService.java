package tn.techcare.PlateformeFormation.service;

import java.sql.Date;
import java.util.List;
import java.util.Optional;

import tn.techcare.PlateformeFormation.model.FormationMetiers;
import tn.techcare.PlateformeFormation.model.ImageModel;
import tn.techcare.PlateformeFormation.model.MessageReponse;

public interface FormationMetiersService {
	public FormationMetiers ajoutFormation( FormationMetiers formation) ;
	public List<FormationMetiers>getAllFormation();
	
	public MessageReponse updateFormation(FormationMetiers formation) ;
	public MessageReponse supprimerFormation(Long id);
	public List<FormationMetiers> getformationbytype(String type ) ;
	

	public List<FormationMetiers> getformationbyintitule(String intitule ) ;

	public List<FormationMetiers> getformationbyPrix(float prix ) ;
	public FormationMetiers getformationbyId(Long id ) ;


	

	
	
}
