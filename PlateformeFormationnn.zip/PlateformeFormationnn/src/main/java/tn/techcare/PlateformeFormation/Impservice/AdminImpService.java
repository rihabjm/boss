package tn.techcare.PlateformeFormation.Impservice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import tn.techcare.PlateformeFormation.entites.MessageResponse;
import tn.techcare.PlateformeFormation.model.Admin;
import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.repository.RoleRepository;
import tn.techcare.PlateformeFormation.repository.UtilisateurRepository;
import tn.techcare.PlateformeFormation.service.AdminService;
@Service
public class AdminImpService implements AdminService {

	@Autowired
    private UtilisateurRepository userRepository ;
@Autowired
    private RoleRepository roleRepository ;
@Autowired
private BCryptPasswordEncoder bCryptPasswordEncoder ;
	
	
	@Override
	public MessageReponse AjoutAdmin(Admin admin) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Admin> getAlladmin() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public MessageReponse ModifierAdmin(Admin admin) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public MessageReponse SupprimerAdmin(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Admin getAdminById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public MessageResponse save(Admin admin) {
		// TODO Auto-generated method stub
		return null;
	}

}
