package tn.techcare.PlateformeFormation.entites;

public class MyConstants {
    // Replace with your email here:  
 
    // Replace password!!
    public static final String MY_PASSWORD = "20454833m";
 
    // And receiver!
    public static final String FRIEND_EMAIL = "rihabjemai35@gmail.com";

	public static final String MY_EMAIL = "Mido.mafia25@gmail.com";

}
