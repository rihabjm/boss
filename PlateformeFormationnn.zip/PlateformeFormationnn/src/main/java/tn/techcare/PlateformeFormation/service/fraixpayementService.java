package tn.techcare.PlateformeFormation.service;

import java.util.List;

import tn.techcare.PlateformeFormation.model.Formateur;
import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.model.fraispayement;

public interface fraixpayementService {
    public MessageReponse Ajouterfraix (fraispayement fraix ,Long  idsession ,Long idformateur ) ;
    public List<Formateur> getfraixbysession(long idsession) ;
    public List<fraispayement> getfraixbyformateur(long idformateur) ;
    public   fraispayement getfraixbyformateursession(Long  idsession ,Long idformateur) ;
     public  MessageReponse modifier(fraispayement fraix);
}
