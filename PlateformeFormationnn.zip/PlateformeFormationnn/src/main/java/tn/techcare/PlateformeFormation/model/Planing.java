package tn.techcare.PlateformeFormation.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
@Entity
@Table(name = "Planing")
public class Planing {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idplaning;
	

	 @JsonIgnore
	    @ManyToOne(cascade = CascadeType.MERGE)
	    @JoinColumn(name = "idsession")
	    private Session session  ;
	 
	 @JsonIgnore
	    @ManyToOne(cascade = CascadeType.MERGE)
	    @JoinColumn(name = "idseance")
	    private Seance senace  ;
	 
	 @JsonIgnore
	    @ManyToOne(cascade = CascadeType.MERGE)
	    @JoinColumn(name = "idsalle")
	    private Salle salle  ;

	 
	 
	public Long getIdplaning() {
		return idplaning;
	}

	public void setIdplaning(Long idplaning) {
		this.idplaning = idplaning;
	}

	public Session getSession() {
		return session;
	}

	public void setSession(Session session) {
		this.session = session;
	}

	public Seance getSenace() {
		return senace;
	}

	public void setSenace(Seance senace) {
		this.senace = senace;
	}

	public Salle getSalle() {
		return salle;
	}

	public void setSalle(Salle salle) {
		this.salle = salle;
	}
	 
	 
	 
	 
	 
	

}
