package tn.techcare.PlateformeFormation.model;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.Table;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@Entity
@Table(name = "Remise")
public class Remise {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idremise;
	 private Date datedebut ;
	   private Date datefin ;
		
	   
		 @JsonIgnore
		    @ManyToOne(cascade = CascadeType.MERGE)
		    @JoinColumn(name = "idsession")
		    private Session session  ;
		 
		 @JsonIgnore
		    @ManyToOne(cascade = CascadeType.MERGE)
		    @JoinColumn(name = "idpromotion")
		    private Promotion promotion  ;
		 
		 
	   
		public Date getDatedebut() {
			return datedebut;
		}

		public void setDatedebut(Date datedebut) {
			this.datedebut = datedebut;
		}
  
		public Date getDatefin() {
			return datefin;
		}

		public void setDatefin(Date datefin) {
			this.datefin = datefin;
		}

	 
	 
	    private float  prixreduit;
       

		public Long getIdremise() {
			return idremise;
		}

		public void setIdremise(Long idremise) {
			this.idremise = idremise;
		}

	


		public float getPrixreduit() {
			return prixreduit;
		}

		public void setPrixreduit(float prixreduit) {
			this.prixreduit = prixreduit;
		}

     	public Promotion getPromotion() {
			return promotion;
		}

		public void setPromotion(Promotion promotion) {
			this.promotion = promotion;
		}

		public Session getSession() {
			return session;
		}

		public void setSession(Session session) {
			this.session = session;
		}


	 
	    
}
