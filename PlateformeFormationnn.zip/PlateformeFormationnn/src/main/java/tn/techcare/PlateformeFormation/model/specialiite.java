package tn.techcare.PlateformeFormation.model;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "Specialite")
public class specialiite {


	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	 private Long idspecialite ;
	private String  nomspecialite ;
	public Long getIdspecialite() {
		return idspecialite;
	}
	public void setIdspecialite(Long idspecialite) {
		this.idspecialite = idspecialite;
	}
	public String getNomspecialite() {
		return nomspecialite;
	}
	public void setNomspecialite(String nomspecialite) {
		this.nomspecialite = nomspecialite;
	}	
	
	  @JsonIgnore
	  @OneToMany(cascade = CascadeType.PERSIST, fetch = FetchType.LAZY)
	    @JoinColumn(name = "id_f")
	    @JsonIgnoreProperties(value = {"certificat"}, allowSetters = true)
	    private List<Certificat> certificats ;
	public List<Certificat> getCertificats() {
		return certificats;
	}
	public void setCertificats(List<Certificat> certificats) {
		this.certificats = certificats;
	}
	
	
}
