package tn.techcare.PlateformeFormation.controller;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.web.bind.annotation.*;

import tn.techcare.PlateformeFormation.model.Data;
import tn.techcare.PlateformeFormation.model.EmailMessage;
import tn.techcare.PlateformeFormation.model.Utilisateur;

import java.io.IOException;
import java.util.List;
import java.util.Observable;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;
@RestController
@CrossOrigin
@RequestMapping("/rest")
public class ContactController {
/*

	    @Autowired
	    private NotificationService notificationService;

	    @PostMapping("/contact")
	    public void sendEmail(@RequestBody Data message) {
	        // send notification
	        try {
	            notificationService.sendFeedback(message);
	        } catch (MailException ex) {
	            
	        }

	    }
	    @PostMapping("/send")
	    public void send(@RequestBody EmailMessage emailmessage ) throws AddressException, MessagingException, IOException {
	    	 
		            notificationService.sendNotification(emailmessage);
		       


	    }*/
	    
}
