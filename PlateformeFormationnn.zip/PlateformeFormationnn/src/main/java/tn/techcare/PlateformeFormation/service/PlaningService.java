package tn.techcare.PlateformeFormation.service;

import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.model.Planing;
public interface PlaningService {
    public MessageReponse Ajouterplaning (Planing planing,  Long  idsession ,int idseance ,Long idsalle ) ;

}
