import { Injectable } from '@angular/core';
import {Remise} from '../Model/remise';
import {HttpClient, HttpParams} from '@angular/common/http';
import {Config} from '../Utils/Config';
import {Observable} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RemiseService {

  private url = Config.BASE_URL + '/remise';
  private urld = this.url + '/add';
private urlremise=this.url+'/bypromotion' ;
  // tslint:disable-next-line:max-line-length
  // private header = new HttpHeaders({'authorization': 'bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1c2VyMUBnbWFpbCIsInJvbGVzIjpbIlVTRVIiXSwiaXNzIjoiL2xvZ2luIiwiZXhwIjoxNTc1NDg4Nzc5fQ.k8ZKAtZUaGXefvsTgqyku_pANq_sH5rbd2NV0xQxLFM'});
  constructor(private httpClient: HttpClient) { }

  add(remise: Remise, idCategory: number,id : number): Observable<object> {
    return this.httpClient.post(`${this.urld}/${idCategory}/${id}`, remise);
  }
 public getsession(id: number): Observable<any> {
    return this.httpClient.get(`${this.urlremise }/${id}`);
  }

}
