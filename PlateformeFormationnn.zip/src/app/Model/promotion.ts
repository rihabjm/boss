import {Observable} from 'rxjs';
import {Formation} from './formation';
export class Promotion {
idpromotion:number ;
designation : String ;
details :String ;
pourcentage : String;
formation :Formation[] ;
}
