import {Observable} from 'rxjs';
import {Formation} from './formation';
import {Formateur} from './formateur';
export class Khademni extends Formation {

idformation:number ;
intitule : String ;
prix :String ;
datedebut : String;
datefin:String ;
etat : String;
type: String ;
description: String ;
formateur :Formateur ;

}
