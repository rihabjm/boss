import { Inscrir } from './inscrir';

describe('Inscrir', () => {
  it('should create an instance', () => {
    expect(new Inscrir()).toBeTruthy();
  });
});
