import { Specilaite } from './specilaite';

describe('Specilaite', () => {
  it('should create an instance', () => {
    expect(new Specilaite()).toBeTruthy();
  });
});
