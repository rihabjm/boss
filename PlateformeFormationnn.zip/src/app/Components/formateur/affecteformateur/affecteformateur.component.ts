import { Component, OnInit } from '@angular/core';
import {FormationService} from '../../../service/formation.service';
import {Formation} from '../../../model/formation';
import {ActivatedRoute, Router} from '@angular/router';
import {Formateur} from '../../../model/formateur';
@Component({
  selector: 'app-affecteformateur',
  templateUrl: './affecteformateur.component.html',
  styleUrls: ['./affecteformateur.component.scss']
})
export class AffecteformateurComponent implements OnInit {

  constructor( ) { }

  ngOnInit() {}
}
