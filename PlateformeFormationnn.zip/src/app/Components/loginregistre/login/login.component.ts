import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {Utilisateur} from '../../../Model/utilisateur';
import {AuthenticationService} from '../../../Service/authentication.service';
import {Router} from '@angular/router';
import { ListformateurComponent } from '../../formateur/listformateur/listformateur.component';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  user: Utilisateur;


  constructor(private formBuilder: FormBuilder, private auth: AuthenticationService, private router: Router) { }

  ngOnInit() {


    this.user = new Utilisateur() ;
  }

  login() {
    console.log('userComponent  ', this.user);
    return this.auth.login(this.user).subscribe(r => {
      const jwt = r.headers.get('Authorization');
      this.auth.saveToken(jwt) ;
      console.log(this.auth.isUser());
      console.log( this.auth.isAdmin());
      console.log( this.auth.isAuthentified());

     if (this.auth.isUser()) {this.router.navigate(['/formateur/lister']); }
     if (this.auth.isAdmin()) {this.router.navigate(['/formateur/ajouter']); }
    }, error => {

    });
  }


}
