import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modifmdp',
  templateUrl: './modifmdp.component.html',
  styleUrls: ['./modifmdp.component.scss']
})
export class ModifmdpComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
