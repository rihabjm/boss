import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-calendrierformation',
  templateUrl: './calendrierformation.component.html',
  styleUrls: ['./calendrierformation.component.scss']
})
export class CalendrierformationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
