import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { OuvrirsessionComponent } from './ouvrirsession/ouvrirsession.component';
import { SessionComponent } from './session/session.component';
import { AffichesessionComponent } from './affichesession/affichesession.component';
import { AffectparticipntComponent } from './affectparticipnt/affectparticipnt.component';
import { SessionparformationComponent } from './sessionparformation/sessionparformation.component';
import { SeancesComponent } from './seances/seances.component';

const routes: Routes = [

            { path: 'session/affichesession', component: AffichesessionComponent} ,
            { path: 'session/ouvrirsession/:id', component: OuvrirsessionComponent } ,
  { path: ':id', component: SessionparformationComponent} ,



                ];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SessionRoutingModule { }
