import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {Utilisateur} from '../Model/utilisateur';
import {AuthenticationService} from '../Service/authentication.service';
import {Router} from '@angular/router';
import { NgbModalConfig, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import {NgControl,ValidationErrors } from '@angular/forms';
import { NgModule } from '@angular/core';
@Component({
  selector: 'app-accplateforme',
  templateUrl: './accplateforme.component.html',
  styleUrls: ['./accplateforme.component.scss']
})
export class AccplateformeComponent implements OnInit {
 loginForm: FormGroup;
  user: Utilisateur;

  constructor(config: NgbModalConfig, private modalService: NgbModal , private formBuilder: FormBuilder, private auth: AuthenticationService, private router: Router) { }

  ngOnInit() {


    this.user = new Utilisateur() ;
  }


 openlogin(contentlogin) {

    this.modalService.open(contentlogin);

  }

opensingin(contentsingin) {

    this.modalService.open(contentsingin);

  }

  login() {
    console.log('userComponent  ', this.user);
    return this.auth.login(this.user).subscribe(r => {
      const jwt = r.headers.get('Authorization');
      this.auth.saveToken(jwt) ;
      console.log(this.auth.isUser());
      console.log( this.auth.isAdmin());
      console.log( this.auth.isAuthentified());

     if (this.auth.isUser()) {this.router.navigate(['/formateur/lister']); }
     if (this.auth.isAdmin()) {this.router.navigate(['/formateur/ajouter']); }
    }, error => {

    });
  }


}
